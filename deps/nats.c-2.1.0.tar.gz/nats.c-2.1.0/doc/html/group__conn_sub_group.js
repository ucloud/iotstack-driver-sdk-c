var group__conn_sub_group =
[
    [ "natsConnection_Subscribe", "group__conn_sub_group.html#gaefab965b5645798d47f9244f2b3fe3fb", null ],
    [ "natsConnection_SubscribeTimeout", "group__conn_sub_group.html#gacb2c83b58b7909715424cbc327fdd404", null ],
    [ "natsConnection_SubscribeSync", "group__conn_sub_group.html#ga17574d5165f7e285462e3d3b2709edf4", null ],
    [ "natsConnection_QueueSubscribe", "group__conn_sub_group.html#ga3c9fee2775130786ef62f1cbeb191a48", null ],
    [ "natsConnection_QueueSubscribeTimeout", "group__conn_sub_group.html#ga96fa115fd5b2ef7658884da80714b91c", null ],
    [ "natsConnection_QueueSubscribeSync", "group__conn_sub_group.html#ga68630ea7c4bbdc7f8cd62058b41fb476", null ]
];