var group__stan_conn_opts_group =
[
    [ "stanConnOptions_Create", "group__stan_conn_opts_group.html#gaff52a1ce90253b4bdbb0005fca4f71b6", null ],
    [ "stanConnOptions_SetURL", "group__stan_conn_opts_group.html#ga3c6d511fc1e1febcdf5344960de5a0b3", null ],
    [ "stanConnOptions_SetNATSOptions", "group__stan_conn_opts_group.html#gae3fc9a4daa7f85367811a313857337b4", null ],
    [ "stanConnOptions_SetConnectionWait", "group__stan_conn_opts_group.html#ga66c72c482696d9ceca71fced7cbb1264", null ],
    [ "stanConnOptions_SetPubAckWait", "group__stan_conn_opts_group.html#ga36f2ee441562dcf619d6e020b823fc96", null ],
    [ "stanConnOptions_SetDiscoveryPrefix", "group__stan_conn_opts_group.html#ga07105d1d00878bba19f47243b2c88402", null ],
    [ "stanConnOptions_SetMaxPubAcksInflight", "group__stan_conn_opts_group.html#ga29eee1be7eff749aeac3bab60d1b0405", null ],
    [ "stanConnOptions_SetPings", "group__stan_conn_opts_group.html#gad835223f08fbeae2a3c7a34d3fa1550b", null ],
    [ "stanConnOptions_SetConnectionLostHandler", "group__stan_conn_opts_group.html#ga19ba15c8001aa835b261eea3a309e6d3", null ],
    [ "stanConnOptions_Destroy", "group__stan_conn_opts_group.html#ga83fd0a29b136cbfb643be642eb2fa726", null ]
];