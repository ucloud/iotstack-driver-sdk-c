var group__stats_group =
[
    [ "natsStatistics_Create", "group__stats_group.html#gafa923df029168f4991b77ffdd9e24877", null ],
    [ "natsStatistics_GetCounts", "group__stats_group.html#gabe5eaa39f967f8c95ed881c835545de1", null ],
    [ "natsStatistics_Destroy", "group__stats_group.html#ga26a04e77af8fc160adf7c33088dcf59c", null ]
];