var group__stan_sub_opts_group =
[
    [ "stanSubOptions_Create", "group__stan_sub_opts_group.html#gad87a2cef4f4ddf64696f9864773c37cf", null ],
    [ "stanSubOptions_SetDurableName", "group__stan_sub_opts_group.html#gaa018bceba99ef3726157e87c6918ab14", null ],
    [ "stanSubOptions_SetAckWait", "group__stan_sub_opts_group.html#gafbb4e6c74978c4e8f30f016c20cc2bdf", null ],
    [ "stanSubOptions_SetMaxInflight", "group__stan_sub_opts_group.html#ga35efbdea888e00440c500845064931c0", null ],
    [ "stanSubOptions_StartAtSequence", "group__stan_sub_opts_group.html#ga6cb7f6e1ac697d16959f9042eeb84dc1", null ],
    [ "stanSubOptions_StartAtTime", "group__stan_sub_opts_group.html#gaafd7a553486eea3c9d309da0744a3608", null ],
    [ "stanSubOptions_StartAtTimeDelta", "group__stan_sub_opts_group.html#ga27d9175901997b8468997019746599b5", null ],
    [ "stanSubOptions_StartWithLastReceived", "group__stan_sub_opts_group.html#ga856a74e31f3307faf988747c1f88717c", null ],
    [ "stanSubOptions_DeliverAllAvailable", "group__stan_sub_opts_group.html#gab09b81358e93199a4631eb06f1ec179f", null ],
    [ "stanSubOptions_SetManualAckMode", "group__stan_sub_opts_group.html#ga6f49ae2629e49d2bfa35990cf030bf83", null ],
    [ "stanSubOptions_Destroy", "group__stan_sub_opts_group.html#ga1b56877d0a6729e148c9c288e2b88e3f", null ]
];