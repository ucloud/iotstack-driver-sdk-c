var NAVTREE =
[
  [ "NATS C Client with Streaming support", "index.html", [
    [ "NATS C client.", "index.html", [
      [ "Introduction", "index.html#intro_sec", null ],
      [ "Installation", "index.html#install_sec", null ],
      [ "Frequently Asked Questions", "index.html#faq_sec", null ],
      [ "Other Documentation", "index.html#other_doc_section", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"deprecated.html",
"group__opts_group.html#gaa1f09416d443fa7a6af6b695da563eba"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';