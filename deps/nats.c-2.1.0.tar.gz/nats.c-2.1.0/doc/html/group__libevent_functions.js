var group__libevent_functions =
[
    [ "natsLibevent_Init", "group__libevent_functions.html#ga195d269473332931fd0fede0bac3309e", null ],
    [ "natsLibevent_Attach", "group__libevent_functions.html#ga30c00f21a5251ee9fde09c1f2b429cd2", null ],
    [ "natsLibevent_Read", "group__libevent_functions.html#ga8a14ce23b4f6ba3bf63369961f9a5552", null ],
    [ "natsLibevent_Write", "group__libevent_functions.html#ga7ac99f326a59e5663ff66f5023c87091", null ],
    [ "natsLibevent_Detach", "group__libevent_functions.html#gaac76f5937329a8650f69c6bd8af36cd5", null ]
];