var group__msg_group =
[
    [ "natsMsg_Create", "group__msg_group.html#ga098e4fec1c5a71c00a0d092fbd6d1a21", null ],
    [ "natsMsg_GetSubject", "group__msg_group.html#gad4597240ee8061b4dbec88576b5e1bed", null ],
    [ "natsMsg_GetReply", "group__msg_group.html#ga3efb98fd6369d9b674638ea93cccf0ab", null ],
    [ "natsMsg_GetData", "group__msg_group.html#ga6bc3cece03b182d2c94e671fd3444cbd", null ],
    [ "natsMsg_GetDataLength", "group__msg_group.html#ga3ed150076a029a5b6a38667d2359e57a", null ],
    [ "natsMsg_Destroy", "group__msg_group.html#ga9e9590018284939f43f60964283f33ae", null ]
];